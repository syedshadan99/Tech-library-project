const banner = document.getElementById('intro');
const images = [
    'image/ict.jpg',
    'image/cyber.jpeg',
    'image/AI.jpg'
];

let currentIndex = 0;

function changeBackground() {
    banner.style.setProperty('--bg-image', `url(${images[currentIndex]})`);
    banner.style.backgroundImage = `url(${images[currentIndex]})`;
    currentIndex = (currentIndex + 1) % images.length;
}

changeBackground();
setInterval(changeBackground, 3000);